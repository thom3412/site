import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyAJSaVoL4EYxrcP8YLdSIFbvFxBHT67fgY",
  authDomain: "appliasa.firebaseapp.com",
  projectId: "appliasa",
  storageBucket: "appliasa.appspot.com",
  messagingSenderId: "242096104027",
  appId: "1:242096104027:web:f52e068d99f2a856ea157e",
  measurementId: "G-4MZJSP62GN"
};

// Vérifier si Firebase n'est pas déjà initialisé
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Activer la persistance hors ligne
try {
  enableIndexedDbPersistence(db);
} catch (err) {
  if (err.code === 'failed-precondition') {
    console.warn('La persistance offline nécessite un seul onglet ouvert à la fois.');
  } else if (err.code === 'unimplemented') {
    console.warn('Le navigateur ne supporte pas la persistance offline.');
  }
}