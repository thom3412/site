import { auth, db, storage } from '../config/firebase';
import { collection, doc, getDoc, setDoc } from 'firebase/firestore';

export const firebaseServices = {
  auth,
  db,
  storage
};

// Fonction pour vérifier si un utilisateur est admin
export async function checkUserIsAdmin(uid: string): Promise<boolean> {
  try {
    const userDoc = await getDoc(doc(db, 'users', uid));
    return userDoc.exists() && userDoc.data()?.isAdmin === true;
  } catch (error) {
    console.error('Erreur lors de la vérification des droits admin:', error);
    return false;
  }
}

// Fonction pour créer un nouvel utilisateur dans Firestore
export async function createUserDocument(uid: string, email: string) {
  try {
    await setDoc(doc(db, 'users', uid), {
      email,
      isAdmin: false, // Par défaut, les nouveaux utilisateurs ne sont pas admin
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Erreur lors de la création du document utilisateur:', error);
  }
}