import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  UserCredential
} from 'firebase/auth';
import { firebaseServices } from './firebase';
import { createUserDocument } from './firebase';

const { auth } = firebaseServices;
const googleProvider = new GoogleAuthProvider();

export const authService = {
  loginWithEmail: async (email: string, password: string): Promise<UserCredential> => {
    return signInWithEmailAndPassword(auth, email, password);
  },

  loginWithGoogle: async (): Promise<UserCredential> => {
    const result = await signInWithPopup(auth, googleProvider);
    await createUserDocument(result.user.uid, result.user.email || '');
    return result;
  },

  register: async (email: string, password: string): Promise<UserCredential> => {
    const result = await createUserWithEmailAndPassword(auth, email, password);
    await createUserDocument(result.user.uid, email);
    return result;
  }
};