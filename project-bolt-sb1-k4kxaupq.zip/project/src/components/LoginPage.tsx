import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, UserPlus } from 'lucide-react';
import LoginForm from './auth/LoginForm';
import RegisterForm from './auth/RegisterForm';
import GoogleButton from './auth/GoogleButton';

export default function LoginPage() {
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSuccess = () => {
    navigate('/home');
  };

  const handleError = (errorMessage: string) => {
    setError(errorMessage);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md w-96">
        <div className="flex justify-center mb-6">
          {isRegistering ? (
            <UserPlus className="h-12 w-12 text-green-600" />
          ) : (
            <LogIn className="h-12 w-12 text-blue-600" />
          )}
        </div>
        
        <h1 className="text-2xl font-bold text-center mb-6">
          {isRegistering ? 'Créer un compte' : 'Connexion'}
        </h1>

        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {error}
          </div>
        )}

        {isRegistering ? (
          <RegisterForm onSuccess={handleSuccess} onError={handleError} />
        ) : (
          <LoginForm onSuccess={handleSuccess} onError={handleError} />
        )}

        <div className="mt-4">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">ou</span>
            </div>
          </div>
        </div>

        <div className="mt-4">
          <GoogleButton onSuccess={handleSuccess} onError={handleError} />
        </div>

        <button
          onClick={() => setIsRegistering(!isRegistering)}
          className="mt-4 w-full text-center text-sm text-gray-600 hover:text-gray-800"
        >
          {isRegistering
            ? 'Déjà un compte ? Se connecter'
            : 'Pas de compte ? S\'inscrire'}
        </button>
      </div>
    </div>
  );
}