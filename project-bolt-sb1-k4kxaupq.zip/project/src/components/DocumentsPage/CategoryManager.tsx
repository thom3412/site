import React from 'react';

interface CategoryManagerProps {
  categories: string[];
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  onNewCategory: (category: string) => void;
  newCategoryInput: string;
  setNewCategoryInput: (value: string) => void;
}

export default function CategoryManager({
  categories,
  selectedCategory,
  onCategoryChange,
  onNewCategory,
  newCategoryInput,
  setNewCategoryInput
}: CategoryManagerProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCategoryInput.trim()) {
      onNewCategory(newCategoryInput.trim());
      setNewCategoryInput('');
    }
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          placeholder="Nouvelle catégorie"
          value={newCategoryInput}
          onChange={(e) => setNewCategoryInput(e.target.value)}
          className="flex-1 p-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
        <button
          type="submit"
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
        >
          Ajouter
        </button>
      </form>

      <select
        value={selectedCategory}
        onChange={(e) => onCategoryChange(e.target.value)}
        className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent"
      >
        <option value="all">Toutes les catégories</option>
        {categories.map(cat => (
          <option key={cat} value={cat}>{cat}</option>
        ))}
      </select>
    </div>
  );
}