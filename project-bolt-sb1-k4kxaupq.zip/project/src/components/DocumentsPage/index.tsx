import React, { useState, useEffect } from 'react';
import { collection, addDoc, deleteDoc, doc, query, onSnapshot } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { firebaseServices, checkUserIsAdmin } from '../../services/firebase';
import { useNavigate } from 'react-router-dom';
import FileUploadZone from './FileUploadZone';
import CategoryManager from './CategoryManager';
import DocumentCard from './DocumentCard';

const { db, storage, auth } = firebaseServices;

interface Document {
  id: string;
  name: string;
  url: string;
  category: string;
  type: string;
  createdAt: number;
}

export default function DocumentsPage() {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [newCategory, setNewCategory] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [categories, setCategories] = useState<string[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAdmin = async () => {
      const user = auth.currentUser;
      if (!user) {
        navigate('/login');
        return;
      }
      
      const adminStatus = await checkUserIsAdmin(user.uid);
      setIsAdmin(adminStatus);
      setLoading(false);
    };

    checkAdmin();
  }, [navigate]);

  useEffect(() => {
    const q = query(collection(db, 'documents'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs: Document[] = [];
      const cats = new Set<string>();
      
      snapshot.forEach((doc) => {
        const data = { ...doc.data(), id: doc.id } as Document;
        docs.push(data);
        if (data.category) cats.add(data.category);
      });
      
      setDocuments(docs.sort((a, b) => b.createdAt - a.createdAt));
      setCategories(Array.from(cats));
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-100 p-8">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Documents</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {documents.map((doc) => (
              <DocumentCard
                key={doc.id}
                document={doc}
                onDelete={() => {}}
                isAdmin={false}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ... reste du code existant pour les admins ...
}