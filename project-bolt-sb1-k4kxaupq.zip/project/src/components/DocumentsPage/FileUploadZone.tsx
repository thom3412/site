import React from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload } from 'lucide-react';

interface FileUploadZoneProps {
  onDrop: (files: File[]) => void;
  category: string;
}

export default function FileUploadZone({ onDrop, category }: FileUploadZoneProps) {
  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png']
    },
    onDrop: (acceptedFiles) => {
      if (!category) {
        alert('Veuillez sélectionner une catégorie avant d\'uploader des fichiers');
        return;
      }
      onDrop(acceptedFiles);
    }
  });

  return (
    <div {...getRootProps()} className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors">
      <input {...getInputProps()} />
      <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
      <p className="text-gray-600">Glissez-déposez des fichiers ici, ou cliquez pour sélectionner</p>
      <p className="text-sm text-gray-500 mt-2">Formats acceptés: PDF, JPG, PNG</p>
    </div>
  );
}