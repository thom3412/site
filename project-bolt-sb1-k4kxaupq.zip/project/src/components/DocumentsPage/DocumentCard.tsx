import React from 'react';
import { Trash2, FileText, Image } from 'lucide-react';

interface DocumentCardProps {
  document: {
    id: string;
    name: string;
    url: string;
    category: string;
    type: string;
  };
  onDelete: (doc: any) => void;
}

export default function DocumentCard({ document, onDelete }: DocumentCardProps) {
  const getIcon = () => {
    if (document.type.includes('pdf')) {
      return <FileText className="h-6 w-6 text-red-500" />;
    }
    return <Image className="h-6 w-6 text-blue-500" />;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow">
      <div className="flex items-center justify-between mb-2">
        {getIcon()}
        <button
          onClick={() => onDelete(document)}
          className="text-red-500 hover:text-red-700 transition-colors"
          title="Supprimer"
        >
          <Trash2 className="h-5 w-5" />
        </button>
      </div>
      <h3 className="font-semibold mb-1 truncate" title={document.name}>
        {document.name}
      </h3>
      <p className="text-sm text-gray-500 mb-2">Catégorie: {document.category}</p>
      <a
        href={document.url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-500 hover:text-blue-700 text-sm inline-block"
      >
        Voir le document
      </a>
    </div>
  );
}