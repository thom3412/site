import React from 'react';
import { authService } from '../../services/auth';

interface GoogleButtonProps {
  onSuccess: () => void;
  onError: (error: string) => void;
}

export default function GoogleButton({ onSuccess, onError }: GoogleButtonProps) {
  const handleGoogleLogin = async () => {
    try {
      await authService.loginWithGoogle();
      onSuccess();
    } catch (err) {
      onError('Erreur lors de la connexion avec Google.');
    }
  };

  return (
    <button
      onClick={handleGoogleLogin}
      className="w-full bg-white text-gray-700 border border-gray-300 py-2 px-4 rounded hover:bg-gray-50 transition duration-200 flex items-center justify-center gap-2"
    >
      <img 
        src="https://www.google.com/favicon.ico" 
        alt="Google" 
        className="w-5 h-5"
      />
      Se connecter avec Google
    </button>
  );
}