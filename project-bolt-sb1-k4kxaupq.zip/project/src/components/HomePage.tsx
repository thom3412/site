import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, ClipboardCheck, Home } from 'lucide-react';

export default function HomePage() {
  const navigate = useNavigate();

  const openMaintenanceForm = () => {
    window.open('https://docs.google.com/forms/u/8/d/e/1FAIpQLSe7Yp_l7d6fHp_idwGTpgSROsGj3o7DwklZkhvflKqXpMFtXA/viewform', '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-12">Tableau de bord</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <button
            onClick={() => navigate('/documents')}
            className="flex flex-col items-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition duration-200"
          >
            <FileText className="h-12 w-12 text-blue-600 mb-4" />
            <span className="text-xl font-semibold">Documents</span>
          </button>

          <button
            onClick={openMaintenanceForm}
            className="flex flex-col items-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition duration-200"
          >
            <ClipboardCheck className="h-12 w-12 text-green-600 mb-4" />
            <span className="text-xl font-semibold">Visite de maintenance</span>
          </button>

          <button
            onClick={() => navigate('/home')}
            className="flex flex-col items-center p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition duration-200"
          >
            <Home className="h-12 w-12 text-purple-600 mb-4" />
            <span className="text-xl font-semibold">Accueil</span>
          </button>
        </div>
      </div>
    </div>
  );
}